start_programa = True 
start_campos = True
campos = 1
PI = 3.14
print("\n--- PROGRAMA INICIADO ---\n")
while start_programa:
    while start_campos:
        match campos:
            case 1:
                try:
                    raio = float(input("Digite o raio da circunferência: "))
                    circ = 2 * PI * raio
                    start_campos = False
                except:
                    print("Valor inválido")
    else:
        print ("O valor da circunferência é:", circ)

        fim_programa = True
        while fim_programa:
                print("\nDeseja finalizar o programa?\n")
                try:
                    confirma = str(input("Digite S (SIM) ou N (FINALIZAR): "))
                    if confirma == "S" or confirma == "s":
                        fim_programa = False
                        start_programa = False
                    elif confirma == "N" or confirma =="n":
                        fim_programa = False
                        start_campos = True
                        campo = 1
                    else:
                        print("Valor inválido")
                except:
                    print("Campo inválido")
else:
        print("\n--- PROGRAMA FINALIZADO ---\n")