start_programa = True 
start_campos = True
campos = 1 
print("\n--- PROGRAMA INICIADO ---\n")
while start_programa:
    while start_campos:
        match campos:
            case 1:
                try:
                    num1 = float(input("Digite o primeiro número:"))
                    campos += 1 
                except:
                    print("Valor inválido")
            case 2:
                try:  
                    num2 = float(input("Digite o segundo número:"))
                    campos += 1
                except:
                    print("Valor inválido")

            case 3:
                print("\n##### INFORME UMA OPERAÇÃO #####\n")
                print("Digite X para multiplicar")
                print("Digite / para dividir")
                print("Digite + para somar")
                print("Digite - para subtrair\n")
                print("\n################################\n")

                while True:
                    oper = input("Digite uma operação: ")
                    if oper in ("x", "X", "/", "+", "-"):
                        start_campos = False
                        break
                else:
                    print("Valor inválido")
    else:
        print("")

        if oper == "x" or oper == "X":
            resultado = num1 * num2
        elif oper == "/":
            resultado = num1 / num2
        elif oper == "+":
            resultado = num1 + num2
        elif oper == "-":
            resultado = num1 - num2
        else:
            resultado = "Você não digitou uma operação válida"

        print("O resultado é", resultado)


        fim_programa = True
        while fim_programa:
            print("\nDeseja finalizar o programa?\n")
            try:
                confirma = str(input("Digite S (SIM) ou N (FINALIZAR): "))
                if confirma == "S" or confirma == "s":
                    fim_programa = False
                    start_programa = False
                elif confirma == "N" or confirma =="n":
                    start_campos = True
                    fim_programa = False
                    campos = 1
                else:
                    print("Valor inválido")
            except:
                print("Campo inválido")
else:
    print("\n--- PROGRAMA FINALIZADO ---\n")