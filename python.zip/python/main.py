start_programa = True
start_campos = True
campo = 1
print("\n--- PROGRAMA INICIADO ---\n")
while start_programa:
    while start_campos:
        match campo:
            case 1:
                try:
                    nome = str(input("Digite seu nome:"))
                    campo += 1
                except:
                    print("Valor inválido")
    
            case 2:
                try:
                    idade = int(input("Digite seu anos:"))
                    campo += 1
                except:
                    print("Valor inválido")

            case 3:
                try:
                    peso = float(input("Digite seu peso:").replace(",", "."))
                    start_campos = False
                except:
                    print("Peso inválido")
    else:
        print ("Seu nome é: ", nome)
        print("Sua idade é:", idade,"anos")
        print("Seu peso é:",peso,"kilos")

        fim_programa = True
        while fim_programa:
            print("\nDeseja finalizar o programa?\n")
            try:
                confirma = str(input("Digite S (SIM) ou N (FINALIZAR): "))
                if confirma == "S" or confirma == "s":
                    fim_programa = False
                    start_programa = False
                elif confirma == "N" or confirma =="n":
                    fim_programa = False
                    start_campos = True
                    campo = 1
                else:
                    print("Valor inválido")
            except:
                print("Campo inválido")
else:
    print("\n--- PROGRAMA FINALIZADO ---\n")